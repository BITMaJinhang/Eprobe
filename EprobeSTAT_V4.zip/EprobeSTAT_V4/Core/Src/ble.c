/*
 * ble.c
 *
 *  Created on: Sep 26, 2024
 *      Author: Administrator
 */


// ble.c

#include "main.h"

 uint8_t rxBuffer[BLE_PARAM_BUFFER_SIZE]; // 接收缓冲区
 volatile uint32_t lastReceiveTime = 0; // 最后接收时间
 volatile uint8_t dataReady = 0; // 数据准备好标志
 volatile uint8_t paramReady = 0; // 数据准备好标志
 UART_HandleTypeDef *huartGlobal; // 全局 UART 句柄
 extern uint32_t TimeTable;
 extern uint8_t Loop_stop;
 Eprobe_param_t BLE_RX_BUFFER;
 extern UART_HandleTypeDef huart1;
 extern UART_HandleTypeDef huart2;
 extern StateMachine Machine[TOTAL_CHANNELS];

void HAL_UART_RxHalfCpltCallback(UART_HandleTypeDef *huart) {
    // 可在这里处理半个缓冲区的接收
//	printf("YEAH!!\n");
}

//void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
//{
//
//#if UART_DEBUG
//	  printf("Received data: ");
//	    for (size_t i = 0; i < BLE_PARAM_BUFFER_SIZE; i++) {
//	        printf("%02X ", rxBuffer[i]); // 假设数据为16进制形式
//	    }
//	    printf("\n");
//#endif
//    // 数据接收完成
//    lastReceiveTime = TimeTable; // 更新接收时间
//    dataReady = 1; // 设置数据准备好标志
//#if UART_DEBUG
//	  printf("lastReceiveTime: %lu\n",lastReceiveTime);
//	  printf("dataReady: %d\n\n",dataReady);
//#endif
//
//	  BLE_Pram_Set();
//
//    // 如果需要继续接收，重新启动DMA接收
//	HAL_UART_Receive_DMA(huartGlobal, rxBuffer, BLE_PARAM_BUFFER_SIZE);
//}

bool BLE_Pram_Set(void){
	switch(BLE_RX_BUFFER.BLE.Channel){
		case CHANNEL_1:
			memcpy(&Machine[CHANNEL_1].param, &BLE_RX_BUFFER, sizeof(Eprobe_param_t));
#if UART_DEBUG
			printf("CHN:%ld\n",Machine[CHANNEL_1].param.BLE.Channel);
			printf("MODE:%ld\n",Machine[CHANNEL_1].param.BLE.Mode);
			printf("SENS:%ld\n",Machine[CHANNEL_1].param.BLE.Sensitivity);
			printf("CMD:%ld\n",Machine[CHANNEL_1].param.BLE.Command);
			for(int i = 0;i<28;i++){
			printf("param[%d]:%f\n",i,Machine[CHANNEL_1].param.BLE.BLE_params[i]);
			}
#endif
			break;
		case CHANNEL_2:
			memcpy(&Machine[CHANNEL_2].param, &BLE_RX_BUFFER, sizeof(Eprobe_param_t));
#if UART_DEBUG
			printf("CHN:%ld\n",Machine[CHANNEL_2].param.BLE.Channel);
			printf("MODE:%ld\n",Machine[CHANNEL_2].param.BLE.Mode);
			printf("SENS:%ld\n",Machine[CHANNEL_2].param.BLE.Sensitivity);
			printf("CMD:%ld\n",Machine[CHANNEL_2].param.BLE.Command);
			for(int i = 0;i<28;i++){
			printf("param[%d]:%f\n",i,Machine[CHANNEL_2].param.BLE.BLE_params[i]);
			}
#endif
			break;
		case CHANNEL_3:
			memcpy(&Machine[CHANNEL_3].param, &BLE_RX_BUFFER, sizeof(Eprobe_param_t));
#if UART_DEBUG
			printf("CHN:%ld\n",Machine[CHANNEL_3].param.BLE.Channel);
			printf("MODE:%ld\n",Machine[CHANNEL_3].param.BLE.Mode);
			printf("SENS:%ld\n",Machine[CHANNEL_3].param.BLE.Sensitivity);
			printf("CMD:%ld\n",Machine[CHANNEL_3].param.BLE.Command);
			for(int i = 0;i<28;i++){
			printf("param[%d]:%f\n",i,Machine[CHANNEL_3].param.BLE.BLE_params[i]);
			}
#endif
			break;
		case CHANNEL_4:
			memcpy(&Machine[CHANNEL_4].param, &BLE_RX_BUFFER, sizeof(Eprobe_param_t));
#if UART_DEBUG
			printf("CHN:%ld\n",Machine[CHANNEL_4].param.BLE.Channel);
			printf("MODE:%ld\n",Machine[CHANNEL_4].param.BLE.Mode);
			printf("SENS:%ld\n",Machine[CHANNEL_4].param.BLE.Sensitivity);
			printf("CMD:%ld\n",Machine[CHANNEL_4].param.BLE.Command);
			for(int i = 0;i<28;i++){
			printf("param[%d]:%f\n",i,Machine[CHANNEL_4].param.BLE.BLE_params[i]);
			}
#endif
			break;
		case CHANNEL_5:
			memcpy(&Machine[CHANNEL_5].param, &BLE_RX_BUFFER, sizeof(Eprobe_param_t));
#if UART_DEBUG
			printf("CHN:%ld\n",Machine[CHANNEL_5].param.BLE.Channel);
			printf("MODE:%ld\n",Machine[CHANNEL_5].param.BLE.Mode);
			printf("SENS:%ld\n",Machine[CHANNEL_5].param.BLE.Sensitivity);
			printf("CMD:%ld\n",Machine[CHANNEL_5].param.BLE.Command);
			for(int i = 0;i<28;i++){
			printf("param[%d]:%f\n",i,Machine[CHANNEL_5].param.BLE.BLE_params[i]);
			}
#endif
			break;
		case CHANNEL_6:
			memcpy(&Machine[CHANNEL_6].param, &BLE_RX_BUFFER, sizeof(Eprobe_param_t));
#if UART_DEBUG
			printf("CHN:%ld\n",Machine[CHANNEL_6].param.BLE.Channel);
			printf("MODE:%ld\n",Machine[CHANNEL_6].param.BLE.Mode);
			printf("SENS:%ld\n",Machine[CHANNEL_6].param.BLE.Sensitivity);
			printf("CMD:%ld\n",Machine[CHANNEL_6].param.BLE.Command);
			for(int i = 0;i<28;i++){
			printf("param[%d]:%f\n",i,Machine[CHANNEL_6].param.BLE.BLE_params[i]);
			}
#endif
			paramReady = 1;
#if UART_DEBUG
			printf("Paramaters are ready.paramReady =%d\n",paramReady);
#endif
			break;
		default:
			break;
		}


	return 0;
}
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    // 数据接收完成
    dataReady = 1; // 设置数据准备好标志
    BLE_Data_Receive();		//将rxBuffer中的数据对应赋值到BLE_RX_BUFFER这个参数结构体中。
    if(BLE_RX_BUFFER.BLE.Channel > CHANNEL_6){//只有6个通道，通道大于六说明不是参数数据，而是配置命令
    	BLE_Cmd(BLE_RX_BUFFER.BLE.Command);//执行配置命令
    }
    else if (BLE_RX_BUFFER.BLE.Channel <= CHANNEL_6)
    {
    	BLE_Pram_Set();		//通道数小于六，配置对应通道参数
    }
    else{
#if UART_DEBUG
printf("Unknown Parameters or Command.\n");
#endif
    }
    // 如果需要继续接收，重新启动DMA接收
	HAL_UART_Receive_DMA(huartGlobal, rxBuffer, BLE_PARAM_BUFFER_SIZE);
}

void BLE_Cmd(uint32_t cmd){//执行命令的函数
	switch(cmd){
	case BLE_CMD_START:
		  Loop_stop = 0;
		  TimeTable = 0;
			Machine[CHANNEL_1].StopFlag = 1;		Machine[CHANNEL_1].Current_State = STATE_INIT;			Machine[CHANNEL_1].timetable = 1;
			Machine[CHANNEL_2].StopFlag = 1;		Machine[CHANNEL_2].Current_State = STATE_INIT;			Machine[CHANNEL_2].timetable = 2;
			Machine[CHANNEL_3].StopFlag = 1;		Machine[CHANNEL_3].Current_State = STATE_INIT;			Machine[CHANNEL_3].timetable = 3;
			Machine[CHANNEL_4].StopFlag = 1;		Machine[CHANNEL_4].Current_State = STATE_INIT;			Machine[CHANNEL_4].timetable = 4;
			Machine[CHANNEL_5].StopFlag = 1;		Machine[CHANNEL_5].Current_State = STATE_INIT;			Machine[CHANNEL_5].timetable = 5;
			Machine[CHANNEL_6].StopFlag = 1;		Machine[CHANNEL_6].Current_State = STATE_INIT;			Machine[CHANNEL_6].timetable = 6;

			#if UART_DEBUG
			printf("BLE_CMD_START.\n");
			#endif
		break;

	case BLE_CMD_STOP:
		Machine[CHANNEL_1].StopFlag = 0;		Machine[CHANNEL_1].Current_State = STATE_DONE;
		Machine[CHANNEL_2].StopFlag = 0;		Machine[CHANNEL_2].Current_State = STATE_DONE;
		Machine[CHANNEL_3].StopFlag = 0;		Machine[CHANNEL_3].Current_State = STATE_DONE;
		Machine[CHANNEL_4].StopFlag = 0;		Machine[CHANNEL_4].Current_State = STATE_DONE;
		Machine[CHANNEL_5].StopFlag = 0;		Machine[CHANNEL_5].Current_State = STATE_DONE;
		Machine[CHANNEL_6].StopFlag = 0;		Machine[CHANNEL_6].Current_State = STATE_DONE;
			#if UART_DEBUG
			printf("BLE_CMD_STOP.\n");
			#endif
		break;
	case BLE_CMD_STOPCHN:
		switch (BLE_RX_BUFFER.BLE.Channel){
		case BLE_CMD_CHANNEL1:
			Machine[CHANNEL_1].StopFlag = 0;		Machine[CHANNEL_1].Current_State = STATE_DONE;
			break;
		case BLE_CMD_CHANNEL2:
			Machine[CHANNEL_2].StopFlag = 0;		Machine[CHANNEL_2].Current_State = STATE_DONE;
			break;
		case BLE_CMD_CHANNEL3:
			Machine[CHANNEL_3].StopFlag = 0;		Machine[CHANNEL_3].Current_State = STATE_DONE;
			break;
		case BLE_CMD_CHANNEL4:
			Machine[CHANNEL_4].StopFlag = 0;		Machine[CHANNEL_4].Current_State = STATE_DONE;
			break;
		case BLE_CMD_CHANNEL5:
			Machine[CHANNEL_5].StopFlag = 0;		Machine[CHANNEL_5].Current_State = STATE_DONE;
			break;
		case BLE_CMD_CHANNEL6:
			Machine[CHANNEL_6].StopFlag = 0;		Machine[CHANNEL_6].Current_State = STATE_DONE;
			break;
		default:
			#if UART_DEBUG
			printf("Unknown stop channel.\n");
			#endif
			break;
	}
		#if UART_DEBUG
		printf("BLE_CMD_STOPCHN[%ld].\n",(BLE_RX_BUFFER.BLE.Channel>>4));
		#endif
		break;

	case BLE_CMD_RESTARTCHN:
		  Loop_stop = 0;
		switch (BLE_RX_BUFFER.BLE.Channel){
		case BLE_CMD_CHANNEL1:
			Machine[CHANNEL_1].StopFlag = 1;		Machine[CHANNEL_1].Current_State = STATE_INIT;
			Machine[CHANNEL_1].timetable = TimeTable;
			break;
		case BLE_CMD_CHANNEL2:
			Machine[CHANNEL_2].StopFlag = 1;		Machine[CHANNEL_2].Current_State = STATE_INIT;
			Machine[CHANNEL_2].timetable = TimeTable+1;
			break;
		case BLE_CMD_CHANNEL3:
			Machine[CHANNEL_3].StopFlag = 1;		Machine[CHANNEL_3].Current_State = STATE_INIT;
			Machine[CHANNEL_3].timetable = TimeTable+2;
			break;
		case BLE_CMD_CHANNEL4:
			Machine[CHANNEL_4].StopFlag = 1;		Machine[CHANNEL_4].Current_State = STATE_INIT;
			Machine[CHANNEL_4].timetable = TimeTable+3;
			break;
		case BLE_CMD_CHANNEL5:
			Machine[CHANNEL_5].StopFlag = 1;		Machine[CHANNEL_5].Current_State = STATE_INIT;
			Machine[CHANNEL_5].timetable = TimeTable+4;
			break;
		case BLE_CMD_CHANNEL6:
			Machine[CHANNEL_6].StopFlag = 1;		Machine[CHANNEL_6].Current_State = STATE_INIT;
			Machine[CHANNEL_6].timetable = TimeTable+5;
			break;
		default:
			#if UART_DEBUG
			printf("Unknown restart channel.\n");
			#endif
			break;
	}
		#if UART_DEBUG
				printf("BLE_CMD_RESTARTCHN[%ld].\n",(BLE_RX_BUFFER.BLE.Channel>>4));
		#endif
		break;

	case BLE_CMD_PAUSECHN:
		switch (BLE_RX_BUFFER.BLE.Channel){
			case BLE_CMD_CHANNEL1:
				Machine[CHANNEL_1].pause_delta_time = Machine[CHANNEL_1].timetable - TimeTable;
				Machine[CHANNEL_1].PauseFlag = 0;
				Set_VBias(&Machine[CHANNEL_1], 0);
				break;
			case BLE_CMD_CHANNEL2:
				Machine[CHANNEL_2].pause_delta_time = Machine[CHANNEL_2].timetable - TimeTable;
				Machine[CHANNEL_2].PauseFlag = 0;
				Set_VBias(&Machine[CHANNEL_2], 0);
				break;
			case BLE_CMD_CHANNEL3:
				Machine[CHANNEL_3].pause_delta_time = Machine[CHANNEL_3].timetable - TimeTable;
				Machine[CHANNEL_3].PauseFlag = 0;
				Set_VBias(&Machine[CHANNEL_3], 0);
				break;
			case BLE_CMD_CHANNEL4:
				Machine[CHANNEL_4].pause_delta_time = Machine[CHANNEL_4].timetable - TimeTable;
				Machine[CHANNEL_4].PauseFlag = 0;
				Set_VBias(&Machine[CHANNEL_4], 0);
				break;
			case BLE_CMD_CHANNEL5:
				Machine[CHANNEL_5].pause_delta_time = Machine[CHANNEL_5].timetable - TimeTable;
				Machine[CHANNEL_5].PauseFlag = 0;
				Set_VBias(&Machine[CHANNEL_5], 0);
				break;
			case BLE_CMD_CHANNEL6:
				Machine[CHANNEL_6].pause_delta_time = Machine[CHANNEL_6].timetable - TimeTable;
				Machine[CHANNEL_6].PauseFlag = 0;
				Set_VBias(&Machine[CHANNEL_6], 0);
				break;
			default:
				#if UART_DEBUG
				printf("Unknown pause channel.\n");
				#endif
				break;
			}
		#if UART_DEBUG
				printf("BLE_CMD_PAUSECHN[%ld].\n",(BLE_RX_BUFFER.BLE.Channel>>4));
		#endif
		break;

	case BLE_CMD_CONTINUECHN:
		switch (BLE_RX_BUFFER.BLE.Channel){
			case BLE_CMD_CHANNEL1:
				Machine[CHANNEL_1].timetable = Machine[CHANNEL_1].pause_delta_time + TimeTable;
				Machine[CHANNEL_1].PauseFlag = 1;
				Set_VBias(&Machine[CHANNEL_1], Machine[CHANNEL_1].VBias);
				break;
			case BLE_CMD_CHANNEL2:
				Machine[CHANNEL_2].timetable = Machine[CHANNEL_2].pause_delta_time + TimeTable;
				Machine[CHANNEL_2].PauseFlag = 1;
				Set_VBias(&Machine[CHANNEL_2], Machine[CHANNEL_2].VBias);
				break;
			case BLE_CMD_CHANNEL3:
				Machine[CHANNEL_3].timetable = Machine[CHANNEL_3].pause_delta_time + TimeTable;
				Machine[CHANNEL_3].PauseFlag = 1;
				Set_VBias(&Machine[CHANNEL_3], Machine[CHANNEL_3].VBias);
				break;
			case BLE_CMD_CHANNEL4:
				Machine[CHANNEL_4].timetable = Machine[CHANNEL_4].pause_delta_time + TimeTable;
				Machine[CHANNEL_4].PauseFlag = 1;
				Set_VBias(&Machine[CHANNEL_4], Machine[CHANNEL_4].VBias);
				break;
			case BLE_CMD_CHANNEL5:
				Machine[CHANNEL_5].timetable = Machine[CHANNEL_5].pause_delta_time + TimeTable;
				Machine[CHANNEL_5].PauseFlag = 1;
				Set_VBias(&Machine[CHANNEL_5], Machine[CHANNEL_5].VBias);
				break;
			case BLE_CMD_CHANNEL6:
				Machine[CHANNEL_6].timetable = Machine[CHANNEL_6].pause_delta_time + TimeTable;
				Machine[CHANNEL_6].PauseFlag = 1;
				Set_VBias(&Machine[CHANNEL_6], Machine[CHANNEL_6].VBias);
				break;
			default:
				#if UART_DEBUG
				printf("Unknown continue channel.\n");
				#endif
				break;
		}
		#if UART_DEBUG
				printf("BLE_CMD_CONTINUE[%ld].\n",(BLE_RX_BUFFER.BLE.Channel>>4));
		#endif
		break;
	default:
#if UART_DEBUG
printf("BLE_CMD_UNKNOWN.\n");
#endif
		break;
	}
}

bool BLE_Data_Receive(void){
	if(dataReady) {
    	parseBLEData(rxBuffer,&BLE_RX_BUFFER);
		// 清理标志
		dataReady = 0;
	}
//
//	printf("BLE_CHN:%ld\n",BLE_RX_BUFFER.BLE.Channel);
//	printf("BLE_MODE:%ld\n",BLE_RX_BUFFER.BLE.Mode);
//	printf("BLE_SENS:%ld\n",BLE_RX_BUFFER.BLE.Sensitivity);
//	printf("BLE_CMD:%ld\n",BLE_RX_BUFFER.BLE.Command);
//	for(int i = 0;i<28;i++){
//	printf("BLE_param[%d]:%f\n",i,BLE_RX_BUFFER.BLE.BLE_params[i]);
//	}
		return true;
}



void BLE_Init(UART_HandleTypeDef *huart) {
	Loop_stop = 1;
    huartGlobal = huart; // 保存 UART 句柄
	HAL_UART_Receive_DMA(huartGlobal, rxBuffer, BLE_PARAM_BUFFER_SIZE);
}

bool CheckBLETimeout(void) {
    if (TimeTable - lastReceiveTime > TIMEOUT_MS) {
#if UART_DEBUG
  printf("BLE_Receive timeout.\n");
#endif
  return 1;
    }else{
    return 0;
    }
}

void Buffer_clear(bool if_timeout){
	if(if_timeout){
//		        memset(rxBuffer, 0, BLE_PARAM_BUFFER_SIZE); // 清空缓冲
//		        HAL_DMA_Abort(huartGlobal->hdmarx);
//		        HAL_Delay(1000);
		        HAL_UART_Receive_DMA(huartGlobal, rxBuffer, BLE_PARAM_BUFFER_SIZE); // 重新启动接收
//		        HAL_Delay(10);
	}
}

bool DecodeBLEData(Eprobe_param_t* BLE_RX_BUFFER) {
    // 示例解码逻辑，请根据具体协议进行实现
	switch(BLE_RX_BUFFER->BLE.Channel){
	case CHANNEL_1:
		return 1;
		break;
	case CHANNEL_2:
		return 1;
		break;
	case CHANNEL_3:
		return 1;
		break;
	case CHANNEL_4:
		return 1;
		break;
	case CHANNEL_5:
		return 1;
		break;
	case CHANNEL_6:
		return 1;
		break;
	default:
		return 0;
		break;
	}
}


// 解析函数
void parseBLEData(const uint8_t* data, Eprobe_param_t* ble) {
    // 确保输入数据和结构体指针不为 NULL
    if (data == NULL || ble == NULL) {
        fprintf(stderr, "Error: Null pointer passed to parseBLEData.\n");
        return;
    }

    memcpy(&ble->BLE.Channel, data, sizeof(uint32_t));              // 复制 Mode
    memcpy(&ble->BLE.Mode, data + 4, sizeof(uint32_t));      // 复制 Channel
    memcpy(&ble->BLE.Sensitivity, data + 8, sizeof(uint32_t));   // 复制 Sensitivity
    memcpy(&ble->BLE.Command, data + 12, sizeof(uint32_t));   // 复制 Sensitivity

    // 解析后面的 28 个 float 数据
    memcpy(ble->BLE.BLE_params, data + 16, sizeof(float) * 28); // 复制 BLE_params

}

//bool BLE_Pram_Set(void){
//	if(dataReady) {
//    	parseBLEData(rxBuffer,&BLE_RX_BUFFER);
////#if UART_DEBUG
////		printf("%d,%lu.\n",1,BLE_RX_BUFFER.BLE.Mode);
////		printf("%d,%lu.\n",2,BLE_RX_BUFFER.BLE.Channel);
////		printf("%d,%lu.\n",3,BLE_RX_BUFFER.BLE.Sensitivity);
////    	for(int i = 0;i<28;i++){
////    	printf("%d,%f.\n",i+4,BLE_RX_BUFFER.BLE.BLE_params[i]);
////    	}
////#endif
//		// 处理接收到的数据
//		if (DecodeBLEData(&BLE_RX_BUFFER)) {
//			printf("Hello yes.\n");
//			return 1;
//			// 解码成功，执行后续操作
//			// 在这里可以添加后续处理逻辑
//		} else {
//			printf("Hello no.\n");
//			return 0;
//			// 解码失败，选择是否进行错误处理
//		}
//		// 清理标志
//		dataReady = 0;
//	}
//		return true;
//}
